<?php $__env->startSection('header'); ?>
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="/">logout</a>
    </nav>
</header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <h1>Booking Confirmed!</h1>
      <div class="booking-details">
        <h2>Booking Details:</h2>
        <table>
            <tr>
                <td><strong>Name:</strong> </td>
                <td><p><?php echo e($name); ?></p></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><p> <?php echo e($email); ?></p></td>
            </tr>
            <tr>
                <td><strong>phone Number:</strong></td>
                <td><p><?php echo e($phonenumber); ?></p></td>
            </tr>
            <tr>
                <td><strong>Train No:</strong></td>
                <td> <p> <?php echo e($trainno); ?></p></td>
            </tr>
            <tr>
                <td><strong>Train Name:</strong></td>
                <td> <p> <?php echo e($trainname); ?></p></td>
            </tr>
            <tr>
                <td><strong>From:</strong></td>
                <td><p> <?php echo e($fromplace); ?></p></td>
            </tr>
            <tr>
                <td><strong>Destination:</strong></td>
                <td><p> <?php echo e($toplace); ?></p></td>
            </tr>
            <tr>
                <td><strong>Departure Time:</strong> </td>
                <td><p><?php echo e($departtime); ?></p></td>
            </tr>
            <tr>
                <td><strong>Date:</strong></td>
                <td><p> <?php echo e($date); ?></p></td>
            </tr>
            <tr>
                <td><strong>Number of Passengers:</strong></td>
                <td> <p><?php echo e($seats); ?></p></td>
            </tr>
        </table>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manojkumar\Downloads\Laravel\app\resources\views/bookingconfirm.blade.php ENDPATH**/ ?>