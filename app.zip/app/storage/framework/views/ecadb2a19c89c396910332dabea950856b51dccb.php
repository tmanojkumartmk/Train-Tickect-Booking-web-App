
<!DOCTYPE html>
<html>
  <head>
    <title>Train Ticket Booking - Search Results</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
}

header {
  background-color: #333;
  color: #fff;
  padding: 20px;
}

nav a {
  color: #fff;
  text-decoration: none;
  margin: 0 10px;
}

nav a:hover {
  text-decoration: underline;
}

main {
  padding: 50px;
  text-align: center;
}

h1 {
  margin-bottom: 50px;
}

.search-results {
  border: 2px solid #333;
  border-radius: 5px;
  padding: 20px;
  margin-bottom: 20px;
  text-align: left;
}

h2 {
  margin-bottom: 10px;
}

button[type="submit"] {
  background-color: #333;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin-top: 10px;
}

footer {
  background-color: #333;
  color: #fff;
  text-align: center;
  padding: 20px;
  position: relative;
  bottom: 0;
  width: 100%;
}
    </style>
  </head>
  <body>
    <header>
      <nav>
        <a href="#">Home</a>
        <a href="#">Search</a>
        <a href="#">Login</a>
        <a href="#">Sign Up</a>
      </nav>
    </header>
    <main>
      <h1>Search Results:</h1>
      <?php $__env->startSection('content'); ?>
      <?php $__env->stopSection(); ?>
      
      <!-- <div class="search-results">
        <h2>Train 2</h2>
        <p>Origin: City B</p>
        <p>Destination: City C</p>
        <p>Departure Time: 11:00 AM</p>
        <p>Arrival Time: 2:30 PM</p>
        <p>Price: $75.00</p>
        <button type="submit">Book Now</button>
      </div>
      <div class="search-results">
        <h2>Train 3</h2>
        <p>Origin: City A</p>
        <p>Destination: City D</p>
        <p>Departure Time: 3:00 PM</p>
        <p>Arrival Time: 7:30 PM</p>
        <p>Price: $100.00</p>
        <button type="submit">Book Now</button>
      </div> -->
    </main>
    <footer>
      <p>&copy; 2021 Train Ticket Booking</p>
    </footer>
  </body>
</html>
<?php /**PATH C:\Users\Manojkumar\Downloads\Laravel\app\resources\views/index.blade.php ENDPATH**/ ?>