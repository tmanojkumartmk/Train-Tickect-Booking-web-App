<?php $__env->startSection('header'); ?>
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="/">logout</a>
    </nav>
</header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <h1>Search Results&emsp;<?php echo e($fromplace); ?>&emsp;To&emsp;<?php echo e($toplace); ?></h1>
<?php for($x=0;$x<count($train);$x++): ?>
    <div class="search-results" id="searchresult" >
        <form action="booking" method="POST" id="searchresult" >
            <?php echo csrf_field(); ?>
            <table>
                <tr>
                    <td>Train NO</td>
                    <td><b><?php echo e($train[$x]->train_number); ?></b></td>
                </tr>
                <tr>
                    <td>Train Name </td>
                    <td><b><?php echo e($train[$x]->train_name); ?></b></td>
                </tr>
                <tr>
                    <td>Orgin Station</td>
                    <td><b><?php echo e($train[$x]->train_origin_station); ?>&emsp;<?php echo e($train[$x]->train_origin_station_code); ?></b></td>
                    <td>To</td>
                    <td><b><?php echo e($train[$x]->train_destination_station); ?>&emsp;<?php echo e($train[$x]->train_destination_station_code); ?></b></td>
                </tr>
                <tr>
                    <td>From Station</td>
                    <td><b><?php echo e($fromplace); ?></b></td>
                    <td>To Station</td>
                    <td><b><?php echo e($toplace); ?></b></td>
                </tr>
                <tr>
                    <td>Time</td>
                    <td><b><?php echo e($train[$x]->depart_time); ?><b></td>
                    <td>To</td>
                    <td><b><?php echo e($train[$x]->arrival_time); ?><b></td>
                </tr>
                <tr>
                    <td>Date</td>
                    <td><b><?php echo e($date); ?></b></td>
                </tr>
            </table>

        <br>
        <input type="hidden" name="trainname" value="<?php echo e($train[$x]->train_name); ?>">
        <input type="hidden" name="trainno" value="<?php echo e($train[$x]->train_number); ?>">
        <input type="hidden" name="fromplace" value="<?php echo e($fromplace); ?>">
        <input type="hidden" name="toplace"value="<?php echo e($toplace); ?>">
        <input type="hidden" name="departtime" value="<?php echo e($train[$x]->depart_time); ?>">
        <input type="hidden" name="date" value="<?php echo e($date); ?>">
        <button type="submit">Book Now</button>
        </form>
    </div>
<?php endfor; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manojkumar\Downloads\Laravel\app\resources\views/searchresult.blade.php ENDPATH**/ ?>