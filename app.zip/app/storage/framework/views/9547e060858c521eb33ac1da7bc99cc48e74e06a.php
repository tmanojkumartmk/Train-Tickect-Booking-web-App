<?php $__env->startSection('content'); ?>
<form action="login" method="post">
    <?php echo csrf_field(); ?>
    <h1>Login</h1>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
    </div>
    <button type="submit">Login</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manojkumar\Downloads\Laravel\app\resources\views/login.blade.php ENDPATH**/ ?>