<?php $__env->startSection('header'); ?>
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="/">logout</a>
    </nav>
</header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="profile">
    <img src="https://vssmn.org/wp-content/uploads/2018/12/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png" alt="Profile Picture">
    <?php echo csrf_field(); ?>
    <h2><?php echo e($data[0]->name); ?></h2>
    <p></p>
    <ul>
      <hr>
      <li>Email: <?php echo e($data[0]->email); ?></li>
      <hr>
      <li>Phone: <?php echo e($data[0]->phonenumber); ?></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manojkumar\Downloads\Laravel\app\resources\views/profile.blade.php ENDPATH**/ ?>