<?php $__env->startSection('header'); ?>
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="logout">logout</a>
    </nav>
</header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <h2>Booking Details:</h2>
    <h2>&emsp;&emsp;  No of Bookings &emsp;&emsp;<?php echo e(sizeOf($bookings)); ?></h2>
<?php for($i=0;$i<sizeOf($bookings);$i++): ?>
<div class="booking-details">
        <table>
            <tr>
                <td><strong>Name:</strong> </td>
                <td><p><?php echo e($bookings[$i]->name); ?></p></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><p> <?php echo e($bookings[$i]->email); ?></p></td>
            </tr>
            <tr>
                <td><strong>phone Number:</strong></td>
                <td><p><?php echo e($bookings[$i]->phonenumber); ?></p></td>
            </tr>
            <tr>
                <td><strong>Train No:</strong></td>
                <td> <p> <?php echo e($bookings[$i]->trainno); ?></p></td>
            </tr>
            <tr>
                <td><strong>Train Name:</strong></td>
                <td> <p> <?php echo e($bookings[$i]->trainname); ?></p></td>
            </tr>
            <tr>
                <td><strong>From:</strong></td>
                <td><p> <?php echo e($bookings[$i]->fromplace); ?></p></td>
            </tr>
            <tr>
                <td><strong>Destination:</strong></td>
                <td><p> <?php echo e($bookings[$i]->toplace); ?></p></td>
            </tr>
            <tr>
                <td><strong>Departure Time:</strong> </td>
                <td><p><?php echo e($bookings[$i]->departtime); ?></p></td>
            </tr>
            <tr>
                <td><strong>Date:</strong></td>
                <td><p> <?php echo e($bookings[$i]->date); ?></p></td>
            </tr>
            <tr>
                <td><strong>Number of Passengers:</strong></td>
                <td> <p><?php echo e($bookings[$i]->seats); ?></p></td>
            </tr>
        </table>
    <form action="deletedata" method="POST" style="none" id="form1">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($bookings[$i]->id); ?>">
        <button type="submit">Cancel</button>
    </form>
    </div>
    <br>
    <br>
<?php endfor; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manojkumar\Downloads\Laravel\app\resources\views/bookingstatus.blade.php ENDPATH**/ ?>