<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\users;

class user extends Controller
{
    public function registerform(){
        return view('register');
    }
    public function register(Request $request){
        $name=$request->input('name');
        $age=$request->input('age');
        $email=$request->input('email');
        $phonenumber=$request->input('phone');
        $password=$request->input('password');
        $confirmpassword=$request->input('confirm-password');
        DB::insert('insert into users (name, age, email, phonenumber, password) values(?, ?, ?, ?, ?)', [$name, $age, $email, $phonenumber, $password]);
        user::temp($name,$email,$phonenumber,$password);
        return view('search');
    }

    public function loginform(){
        return view('login');
    }

    public function login(Request $request){
        $email=$request->input('email');
        $password=$request->input('password');
        $data=DB::select('select * from users where email = ?', [$email]);
        if(sizeOf($data)>0){
            if($password==$data[0]->password){
                user::temp($data[0]->name, $data[0]->email, $data[0]->phonenumber, $data[0]->password);
                return view('search');
            }
            else{
                return view('login');
            }
        }
        else{
            return view('login');
        }
    }
    public function searchresult(Request $request){
         $Trains=json_decode('{"status":true,"message":"Success","timestamp":1678598247780,"data":[{"train_number":"22676","train_name":"Chozhan Express","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Tiruchirapalli","train_origin_station_code":"TPJ","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"12:10:00","arrival_time":"17:30:00","distance":"281","class_type":["1A","2A","3A","SL","2S"],"day_of_journey":1},{"train_number":"16852","train_name":"Rmm Ms Express","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"01:00:00","arrival_time":"06:45:00","distance":"280","class_type":["1A","2A","3A","SL"],"day_of_journey":2},{"train_number":"06796","train_name":"Cholan Express Special","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Tiruchirapalli","train_origin_station_code":"TPJ","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"12:10:00","arrival_time":"17:40:00","distance":"281","class_type":["1A","2A","3A","SL","2S"],"day_of_journey":1},{"train_number":"08495","train_name":"Rameswaram - Bhubaneswar Special Fare Special","train_type":"M","run_days":["Sat"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Bhubaneswar","train_destination_station_code":"BBS","depart_time":"16:07:00","arrival_time":"21:55:00","distance":"280","class_type":["2A","3A","SL","2S"],"day_of_journey":1},{"train_number":"16793","train_name":"Shraddha Sethu","train_type":"M","run_days":["Sat"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Faizabad","train_destination_station_code":"AYC","depart_time":"07:15:00","arrival_time":"12:35:00","distance":"280","class_type":["1A","2A","3A","SL"],"day_of_journey":2},{"train_number":"22624","train_name":"Mdu Ms Express","train_type":"M","run_days":["Wed","Fri"],"train_origin_station":"Madurai","train_origin_station_code":"MDU","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"01:15:00","arrival_time":"06:55:00","distance":"280","class_type":["2A","3A","SL"],"day_of_journey":2},{"train_number":"09420","train_name":"Tpj Adi Special","train_type":"M","run_days":["Sat"],"train_origin_station":"Tiruchirapalli","train_origin_station_code":"TPJ","train_destination_station":"Ahmedabad","train_destination_station_code":"ADI","depart_time":"08:55:00","arrival_time":"14:40:00","distance":"281","class_type":["2A","3A","SL"],"day_of_journey":1},{"train_number":"07686","train_name":"Rmm Sc Spl","train_type":"M","run_days":["Sun"],"train_origin_station":"Thanjavur","train_origin_station_code":"TJ","train_destination_station":"Hyderabad","train_destination_station_code":"SC","depart_time":"08:35:00","arrival_time":"14:00:00","distance":"280","class_type":["2A","3A","SL"],"day_of_journey":1},{"train_number":"06044","train_name":"Kcvl Tbm Spl","train_type":"M","run_days":["Mon"],"train_origin_station":"Thiruvananthapuram","train_origin_station_code":"KCVL","train_destination_station":"Chennai","train_destination_station_code":"TBM","depart_time":"00:25:00","arrival_time":"06:20:00","distance":"255","class_type":["3A","SL"],"day_of_journey":2},{"train_number":"16186","train_name":"Velankanni Exp","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Nagapattinam","train_origin_station_code":"VLNK","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"23:20:00","arrival_time":"05:15:00","distance":"280","class_type":["3A","SL"],"day_of_journey":1},{"train_number":"16176","train_name":"Kik Ms Express","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Karaikal","train_origin_station_code":"KIK","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"23:35:00","arrival_time":"05:05:00","distance":"281","class_type":["2A","3A","SL","2S"],"day_of_journey":1},{"train_number":"07696","train_name":"Rmd Sc Special","train_type":"M","run_days":["Thu"],"train_origin_station":"Ramanathapuram","train_origin_station_code":"RMD","train_destination_station":"Hyderabad","train_destination_station_code":"SC","depart_time":"16:07:00","arrival_time":"21:50:00","distance":"280","class_type":["1A","2A","3A","SL"],"day_of_journey":1},{"train_number":"20895","train_name":"Rmm Bbs Express","train_type":"M","run_days":["Sat"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Bhubaneswar","train_destination_station_code":"BBS","depart_time":"16:07:00","arrival_time":"21:55:00","distance":"280","class_type":["2A","3A","SL"],"day_of_journey":1},{"train_number":"18495","train_name":"Bhubaneswar Exp","train_type":"M","run_days":["Sat"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Bhubaneswar","train_destination_station_code":"BBS","depart_time":"15:48:00","arrival_time":"22:05:00","distance":"280","class_type":["2A","3A","SL"],"day_of_journey":1},{"train_number":"16864","train_name":"Mq Bgkt Exp","train_type":"M","run_days":["Sun"],"train_origin_station":"Mannargudi","train_origin_station_code":"MQ","train_destination_station":"Jodhpur","train_destination_station_code":"BGKT","depart_time":"13:50:00","arrival_time":"19:25:00","distance":"280","class_type":["2A","3A","SL"],"day_of_journey":1},{"train_number":"16180","train_name":"Mq Ms Express","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Mannargudi","train_origin_station_code":"MQ","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"00:05:00","arrival_time":"05:30:00","distance":"281","class_type":["1A","2A","3A","SL"],"day_of_journey":2},{"train_number":"22674","train_name":"Mq Bgkt Express","train_type":"M","run_days":["Sun"],"train_origin_station":"Mannargudi","train_origin_station_code":"MQ","train_destination_station":"Jodhpur","train_destination_station_code":"BGKT","depart_time":"14:45:00","arrival_time":"19:35:00","distance":"281","class_type":["2A","3A","SL"],"day_of_journey":1},{"train_number":"16106","train_name":"Tcn Chennai Exp","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Tiruchchendur","train_origin_station_code":"TCN","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"05:00:00","arrival_time":"10:25:00","distance":"281","class_type":["1A","2A","3A","SL"],"day_of_journey":2},{"train_number":"16866","train_name":"Uzhavan Express","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Thanjavur","train_origin_station_code":"TJ","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"23:10:00","arrival_time":"04:25:00","distance":"280","class_type":["1A","2A","3A","SL","2S"],"day_of_journey":1},{"train_number":"22535","train_name":"Rmm Bsbs Exp","train_type":"M","run_days":["Tue"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Varanasi","train_destination_station_code":"BSBS","depart_time":"08:00:00","arrival_time":"12:50:00","distance":"280","class_type":["2A","3A","SL","2S"],"day_of_journey":2},{"train_number":"16796","train_name":"Chozhan Express","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Tiruchirapalli","train_origin_station_code":"TPJ","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"12:10:00","arrival_time":"17:30:00","distance":"280","class_type":["1A","2A","3A","SL","2S"],"day_of_journey":1},{"train_number":"16192","train_name":"Tbm Antyodaya","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Nagercoil","train_origin_station_code":"NCJ","train_destination_station":"Chennai","train_destination_station_code":"TBM","depart_time":"00:35:00","arrival_time":"05:40:00","distance":"255","class_type":["2S"],"day_of_journey":2},{"train_number":"16752","train_name":"Rmm Ms Express","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Chennai","train_destination_station_code":"MS","depart_time":"01:00:00","arrival_time":"06:45:00","distance":"280","class_type":["1A","2A","3A","SL"],"day_of_journey":2},{"train_number":"06068","train_name":"Ers Tbm Spl","train_type":"M","run_days":["Sun"],"train_origin_station":"Cochin","train_origin_station_code":"ERS","train_destination_station":"Chennai","train_destination_station_code":"TBM","depart_time":"06:15:00","arrival_time":"12:00:00","distance":"256","class_type":["2A","3A","SL"],"day_of_journey":2},{"train_number":"20692","train_name":"Tbm Antyodaya","train_type":"M","run_days":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"train_origin_station":"Nagercoil","train_origin_station_code":"NCJ","train_destination_station":"Chennai","train_destination_station_code":"TBM","depart_time":"00:35:00","arrival_time":"05:50:00","distance":"256","class_type":["2S"],"day_of_journey":2},{"train_number":"22613","train_name":"Rmm Ayc Express","train_type":"M","run_days":["Sat"],"train_origin_station":"Rameswaram","train_origin_station_code":"RMM","train_destination_station":"Faizabad","train_destination_station_code":"AYC","depart_time":"08:00:00","arrival_time":"12:50:00","distance":"280","class_type":["2A","3A","SL"],"day_of_journey":2},{"train_number":"11018","train_name":"Kik Ltt Express","train_type":"M","run_days":["Sun"],"train_origin_station":"Karaikal","train_origin_station_code":"KIK","train_destination_station":"Mumbai","train_destination_station_code":"LTT","depart_time":"16:07:00","arrival_time":"21:50:00","distance":"281","class_type":["2A","3A","SL"],"day_of_journey":1}]}');
        $train=$Trains->data;
        $curl = curl_init();
                // for RAILWAY API
        /*curl_setopt_array($curl, [
        CURLOPT_URL => "https://irctc1.p.rapidapi.com/api/v2/trainBetweenStations?fromStationCode=mv&toStationCode=mas",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
        		"X-RapidAPI-Host: irctc1.p.rapidapi.com",
        		"X-RapidAPI-Key: env(RAILWAY_API)"
        	],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
        	echo "cURL Error #:" . $err;
        } else {
        	echo $response;
        }*/

        $fromplace=$request->input('from');
        $toplace=$request->input('to');
        $date=$request->input('date');
        return view('searchresult',compact('train','fromplace','toplace','date'));
    }

    public function profile(){
       $data=DB::select('select * from temps where id = ?', [1]);
       return view('profile',compact('data'));
    }

    public function booking(Request $request){
        $trainname=$request->input('trainname');
        $trainno=$request->input('trainno');
        $fromplace=$request->input('fromplace');
        $toplace=$request->input('toplace');
        $departtime=$request->input('departtime');
        $date=$request->input('date');
        return view('booking',compact('trainname','trainno','fromplace','toplace','departtime','date'));
    }
    public function home(){
        return view('search');
    }
    public function bookingstatus(){
        $email=DB::select('select email from temps where id = ?', [1]);
        $bookings=DB::select('select * from bookings where email = ?', [$email[0]->email]);
        return view('bookingstatus',compact('bookings'));
    }
    public function bookingconfirm(Request $request){
        $data=DB::select('select * from temps where id = ?', [1]);
        $name=$data[0]->name;
        $email=$data[0]->email;
        $trainname=$request->input('trainname');
        $trainno=$request->input('trainno');
        $fromplace=$request->input('fromplace');
        $toplace=$request->input('toplace');
        $departtime=$request->input('departtime');
        $date=$request->input('date');
        $phonenumber=$request->input('phonenumber');
        $seats=$request->input('seats');
        DB::insert('insert into bookings (name,email,trainno,trainname,fromplace,toplace,departtime,date,phonenumber,seats) values (?,?,?,?,?,?,?,?,?,?)', [$name,$email,$trainno,$trainname,$fromplace,$toplace,$departtime,$date,$phonenumber,$seats]);
        return view('bookingconfirm',compact('name','email','trainno','trainname','fromplace','toplace','departtime','date','phonenumber','seats'));
    }
    public function deletedata(Request $request){
        DB::delete('delete from bookings where id = ?', [$request->input('id')]);
        return user::bookingstatus();
    }
    public function logout(){
        DB::delete('delete from temps where id = ?', [1]);
        return view('login');
    }
    public function temp($name,$email,$phonenumber,$password){
        $data=DB::select('select * from temps where id = ?', [1]);
        if(sizeOf($data)>0){
            DB::update('update temps set name=?, email=?, phonenumber=?, password=? where id = ?', [$name,$email,$phonenumber,$password]);
        }
        else{
            DB::insert('insert into temps (name, email, phonenumber, password) values (?, ?, ?, ?)', [$name,$email,$phonenumber,$password]);
        }
    }
}

