@extends('layout.index')
@section('header')
<header>
    <nav>
      <a href="search">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="/">logout</a>
    </nav>
</header>
@endsection
@section('content')
<h2>Welcome to Train Ticket Booking</h2>
<form action="searchresult" method="POST">
    @csrf
  <label for="from">From:</label >
  <input type="text" id="from" name="from" required>
  <label for="to">To:</label>
  <input type="text" id="to" name="to" required>
  <label for="date">Date:</label>
  <input type="date" id="date" name="date" required>
  <button type="submit">Search Trains</button>
</form>
@endsection
