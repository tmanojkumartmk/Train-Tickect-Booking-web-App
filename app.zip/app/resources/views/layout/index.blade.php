
<!DOCTYPE html>
<html>
  <head>
    <title>Train Ticket Booking</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
        -ms-scroll-snap-y: none;
    }

    header {
        width: 100%;
        background-color: #569424;
        color: #fff;
        padding: 20px;
    }

    nav a {
        color: #fff;
        text-decoration: none;
        margin: 0 10px;
    }

    nav a:hover {
        text-decoration: underline;
    }

    main {
        padding: 50px;
        text-align: center;
    }

    h1 {
        margin-bottom: 50px;
    }

    .search-results #searchresult {
        border: 2px solid #6dca1c;
        border-radius: 5px;
        padding: 20px;
        margin-bottom: 20px;
        text-align: left;
    }
    h2 {
        margin-bottom: 10px;
    }
    main {
        padding: 50px;
        text-align: center;
    }
    .booking-details,form {
        border: 2px solid #333;
        border-radius: 5px;
        padding: 20px;
        margin-bottom: 20px;
        text-align: left;
        max-width: 500px;
        margin: 0 auto;
    }
    .form-group {
        margin-bottom: 20px;
    }
    label {
        display: block;
        margin-bottom: 5px;
    }
    input {
        height: 30px;
        padding: 5px;
        font-size: 16px;
        width: 100%;
        box-sizing: border-box;
        border-radius: 5px;
        border: 2px solid #ccc;
    }
    button {
        margin-top: 10px;
        background-color: #32c107;
        color: #fff;
        border: none;
        border-radius: 5px;
        height: 40px;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
    }

    button:hover {
        background-color: #555;
    }
        .profile {
        border: 2px solid #333;
        border-radius: 5px;
        padding: 20px;
        margin-bottom: 20px;
        text-align: left;
        max-width: 500px;
        margin: 0 auto;
    }

    .profile img {
        width: 100px;
        border-radius: 50%;
        margin-bottom: 20px;
    }

    .profile h2 {
        margin-bottom: 5px;
    }

    .profile p {
        margin-bottom: 20px;
    }

    .profile ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .profile ul li {
        margin-bottom: 5px;
    }
    .booking td {
            padding-left: 5px;
            padding-right: 20px;
    }
    .search-results table {
        border-spacing: 10px;
    }
    #form1{
        border: 0;
    }
    </style>
</head>
<body>
    @section('header')
    <header>
        <nav>
          <a href="/">Home</a>
          <a href="/">Search</a>
          <a href="/">Login</a>
          <a href="registerform">Register</a>
        </nav>
    </header>
    @show
    <main>
      @section('content')
      @show
    </main>
</body>
</html>
