@extends('layout.index')
@section('header')
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="logout">logout</a>
    </nav>
</header>
@endsection
@section('content')
        <h1>Search Results&emsp;{{$fromplace}}&emsp;To&emsp;{{$toplace}}</h1>
@for($x=0;$x<count($train);$x++)
    <div class="search-results" id="searchresult" >
        <form action="booking" method="POST" id="searchresult" >
            @csrf
            <table>
                <tr>
                    <td>Train NO</td>
                    <td><b>{{$train[$x]->train_number}}</b></td>
                </tr>
                <tr>
                    <td>Train Name </td>
                    <td><b>{{$train[$x]->train_name}}</b></td>
                </tr>
                <tr>
                    <td>Orgin Station</td>
                    <td><b>{{$train[$x]->train_origin_station}}&emsp;{{$train[$x]->train_origin_station_code}}</b></td>
                    <td>To</td>
                    <td><b>{{$train[$x]->train_destination_station}}&emsp;{{$train[$x]->train_destination_station_code}}</b></td>
                </tr>
                <tr>
                    <td>From Station</td>
                    <td><b>{{$fromplace}}</b></td>
                    <td>To Station</td>
                    <td><b>{{$toplace}}</b></td>
                </tr>
                <tr>
                    <td>Time</td>
                    <td><b>{{$train[$x]->depart_time}}<b></td>
                    <td>To</td>
                    <td><b>{{$train[$x]->arrival_time}}<b></td>
                </tr>
                <tr>
                    <td>Date</td>
                    <td><b>{{$date}}</b></td>
                </tr>
            </table>

        <br>
        <input type="hidden" name="trainname" value="{{$train[$x]->train_name}}">
        <input type="hidden" name="trainno" value="{{$train[$x]->train_number}}">
        <input type="hidden" name="fromplace" value="{{$fromplace}}">
        <input type="hidden" name="toplace"value="{{$toplace}}">
        <input type="hidden" name="departtime" value="{{$train[$x]->depart_time}}">
        <input type="hidden" name="date" value="{{$date}}">
        <button type="submit">Book Now</button>
        </form>
    </div>
@endfor
@endsection
