@extends('layout.index')
@section('header')
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="logout">logout</a>
    </nav>
</header>
@endsection
@section('content')
<h2>Booking Details</h2>
<form class="booking" action="bookingconfirm" method="POST">
    @csrf
    <table>
        <tr>
            <td>Train No</td>
            <td><h4>{{$trainno}}</h4></td>
        </tr>
        <tr>
            <td>Train Name</td>
            <td><h4>{{$trainname}}</h4></td>
        </tr>
        <tr>
            <td>From</td>
            <td><h4>{{$fromplace}}</h4></td>
            <td>To</td>
            <td><h4>{{$toplace}}</h4></td>
        </tr>
        <tr>
            <td>Date</td>
            <td><h4>{{$date}}</h4></td>
            <td>Time</td>
            <td>{{$departtime}}</td>
        </tr>
    </table>
  <label for="phone">Phone Number:</label>
  <input type="tel" id="phone" name="phonenumber" required>
  <label for="seats">Number of Seats:</label>
  <input type="number" id="seats" name="seats" min="1" max="10" required>

  <input type="hidden" name="trainname" value="{{$trainname}}">
        <input type="hidden" name="trainno" value="{{$trainno}}">
        <input type="hidden" name="fromplace" value="{{$fromplace}}">
        <input type="hidden" name="toplace"value="{{$toplace}}">
        <input type="hidden" name="departtime" value="{{$departtime}}">
        <input type="hidden" name="date" value="{{$date}}">
  <button type="submit">Confirm Booking</button>
</form>
@endsection
