@extends('layout.index')
@section('header')
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="logout">logout</a>
    </nav>
</header>
@endsection
@section('content')
      <h1>Booking Confirmed!</h1>
      <div class="booking-details">
        <h2>Booking Details:</h2>
        <table>
            <tr>
                <td><strong>Name:</strong> </td>
                <td><p>{{$name}}</p></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><p> {{$email}}</p></td>
            </tr>
            <tr>
                <td><strong>phone Number:</strong></td>
                <td><p>{{$phonenumber}}</p></td>
            </tr>
            <tr>
                <td><strong>Train No:</strong></td>
                <td> <p> {{$trainno}}</p></td>
            </tr>
            <tr>
                <td><strong>Train Name:</strong></td>
                <td> <p> {{$trainname}}</p></td>
            </tr>
            <tr>
                <td><strong>From:</strong></td>
                <td><p> {{$fromplace}}</p></td>
            </tr>
            <tr>
                <td><strong>Destination:</strong></td>
                <td><p> {{$toplace}}</p></td>
            </tr>
            <tr>
                <td><strong>Departure Time:</strong> </td>
                <td><p>{{$departtime}}</p></td>
            </tr>
            <tr>
                <td><strong>Date:</strong></td>
                <td><p> {{$date}}</p></td>
            </tr>
            <tr>
                <td><strong>Number of Passengers:</strong></td>
                <td> <p>{{$seats}}</p></td>
            </tr>
        </table>
      </div>

@endsection
