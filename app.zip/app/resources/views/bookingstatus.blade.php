@extends('layout.index')
@section('header')
<header>
    <nav>
      <a href="home">Home</a>
      <a href="profile">Profile</a>
      <a href="bookingstatus">Booking Status</a>
      <a href="logout">logout</a>
    </nav>
</header>
@endsection
@section('content')

    <h2>Booking Details:</h2>
    <h2>&emsp;&emsp;  No of Bookings &emsp;&emsp;{{sizeOf($bookings)}}</h2>
@for($i=0;$i<sizeOf($bookings);$i++)
<div class="booking-details">
        <table>
            <tr>
                <td><strong>Name:</strong> </td>
                <td><p>{{$bookings[$i]->name}}</p></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><p> {{$bookings[$i]->email}}</p></td>
            </tr>
            <tr>
                <td><strong>phone Number:</strong></td>
                <td><p>{{$bookings[$i]->phonenumber}}</p></td>
            </tr>
            <tr>
                <td><strong>Train No:</strong></td>
                <td> <p> {{$bookings[$i]->trainno}}</p></td>
            </tr>
            <tr>
                <td><strong>Train Name:</strong></td>
                <td> <p> {{$bookings[$i]->trainname}}</p></td>
            </tr>
            <tr>
                <td><strong>From:</strong></td>
                <td><p> {{$bookings[$i]->fromplace}}</p></td>
            </tr>
            <tr>
                <td><strong>Destination:</strong></td>
                <td><p> {{$bookings[$i]->toplace}}</p></td>
            </tr>
            <tr>
                <td><strong>Departure Time:</strong> </td>
                <td><p>{{$bookings[$i]->departtime}}</p></td>
            </tr>
            <tr>
                <td><strong>Date:</strong></td>
                <td><p> {{$bookings[$i]->date}}</p></td>
            </tr>
            <tr>
                <td><strong>Number of Passengers:</strong></td>
                <td> <p>{{$bookings[$i]->seats}}</p></td>
            </tr>
        </table>
    <form action="deletedata" method="POST" style="none" id="form1">
        @csrf
        <input type="hidden" name="id" value="{{$bookings[$i]->id}}">
        <button type="submit">Cancel</button>
    </form>
    </div>
    <br>
    <br>
@endfor


@endsection

