<?php

use Illuminate\Support\Facades\Route;

use Illuminate\Http\Request;
use App\Http\Controllers\user;

Route::get('/',[user::class,'loginform']);
Route::post('login',[user::class,'login']);
Route::get('registerform',[user::class,'registerform']);
Route::post('register',[user::class,'register']);
Route::get('home',[user::class,'home']);
Route::post('searchresult',[user::class,'searchresult']);
Route::get('profile',[user::class,'profile']);
Route::post('booking',[user::class,'booking']);
Route::post('bookingconfirm',[user::class,'bookingconfirm']);
Route::get('bookingstatus',[user::class,'bookingstatus']);
Route::post('deletedata',[user::class,'deletedata']);
Route::get('logout',[user::class,'logout']);

